from django.urls import path
from app_base import views

urlpatterns = [
        #inicio fruteria
    path('', views.inicio),
]
